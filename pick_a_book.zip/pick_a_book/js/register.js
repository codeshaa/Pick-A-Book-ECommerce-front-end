function validateForm() {
    var first_name = document.getElementById("first_name").value;
    if (first_name.length< 5) {
        alert("First Name has atleast 5 character");
        return false;
    }
    var last_name = document.getElementById("last_name").value;
    if (last_name.length< 8) {
        alert("Last Name has atleast 8 character");
        return false;
    }    
    var password = document.getElementById("password").value;
    if(password.length<5){
    	alert("password has atleast 5 character");
    	return false;
    }
    