$(document).ready(function(){

  //function to calculate total

  function calTotal()
  {
    var total = 0;

    for(var i = 1;i<k; i++)
    {
      if( $('#subtotal_'+i).length > 0 )
      {
        total = parseInt(total) + parseInt($('#subtotal_'+i).text());
      }
    }
    
    $('#total').text(total);
  }

  // Delete functinality
  $(document).on("click",".data_remove",function(){ 
    $(this).parent().parent().remove();   
    calTotal();  
    
  });

  //quantity increment
  $(document).on("click",".product_quantity",function() {
      var id = $(this).parent().parent().attr('data-id');
      var price = parseInt($('#price_'+id).text());
      var qty = parseInt($(this).val());
      if(qty<1){
        $(this).val('1');
      }
      else
      {
      $('#subtotal_'+id).text(price*qty);
      calTotal();
      }
  });


  
  // show categories and products
  if($("#container1").is(':visible')==true)
  { 
    
  	$.ajax({method: "GET",url: "product.json",dataType: "json"}).done(function(result)
  	{	
        var i=1; var j=1; 
         
          	$.each(result,function(index,value)
            {   
                $("#category_"+i).show();
            		$("#category_"+i).text(index);
              		
                    if(i==1)
                      {
                        $("#category_name").text(index);
                          $.each(value,function(ind,val)
                          { 
                            $("#product_"+j).show();            
                            $("#product_"+j).find('h3').text(val.price);
                            $("#product_"+j).find('img').attr('src',val.src);
                            $("#product_"+j).find('P').text(val.description);
                            j++;
                          });
                      }
                  i++;
                
                
            });
        
        

        $("#category_1").addClass("active");     

    });
  }
  if($("#container1").is(':visible')==true)
  {
    // show products on select categories
  	$(".category_show").on('click',function()
    { 
      $(".shopping_cart_show").hide();
      $(".product_detail_show").show();
      $('li a').removeClass("active");
  		var category_name = $(this).text();
      $("#category_name").text(category_name);

  		var j=1;  		
			$.each(full_info,function(index,value){
				
				if(index==category_name)
				{ 
					$.each(value,function(ind,val){

						$("#product_"+j).show();
						$("#product_"+j).find('.product_price').text(val.price);
            $("#product_"+j).find('.product_name').text(val.name);
						$("#product_"+j).find('img').attr('src',val.src);
						$("#product_"+j).find('.product_description').text(val.description);
						j++;

					}); 

				}

			});
  		

  	});
  }
    var k=1; 
    // shopping cart functionality
  $(".shopping_cart").on('click',function()
  {     
      var price       = $(this).parent().siblings().first().text();
      var name        = $(this).parent().siblings().first().next().text();
      var description = $(this).parent().siblings().last().text();
      var src         = $(this).parent().parent().siblings().attr('src');
    
      $("#container2").hide();
      $("#container1").show();
       // show categories and products
  if($("#container1").is(':visible')==true)
  { 
    var full_info = new Object();
    $.ajax({method: "GET",url: "product.json",dataType: "json"}).done(function(result)
    { 
        var i=1; var j=1; full_info = result;
         
            $.each(result,function(index,value)
            {   
                $("#category_"+i).show();
                $("#category_"+i).text(index);
                  
                    if(i==1)
                      {
                        $("#category_name").text(index);
                          $.each(value,function(ind,val)
                          { 
                            $("#product_"+j).show();            
                            $("#product_"+j).find('h3').text(val.price);
                            $("#product_"+j).find('img').attr('src',val.src);
                            $("#product_"+j).find('P').text(val.description);
                            j++;
                          });
                      }
                  i++;
                
                
            });
        
        

        $("#category_1").addClass("active");     

    });
  }
  if($("#container1").is(':visible')==true)
  {
    // show products on select categories
    $(".category_show").on('click',function()
    { 
      $(".shopping_cart_show").hide();
      $(".product_detail_show").show();
      $('li a').removeClass("active");
      var category_name = $(this).text();
      $("#category_name").text(category_name);

      var j=1;      
      $.each(full_info,function(index,value){
        
        if(index==category_name)
        { 
          $.each(value,function(ind,val){

            $("#product_"+j).show();
            $("#product_"+j).find('.product_price').text(val.price);
            $("#product_"+j).find('.product_name').text(val.productname);
            $("#product_"+j).find('img').attr('src',val.src);
            $("#product_"+j).find('.product_description').text(val.description);
            j++;

          }); 

        }

      });
      

    });
  }

      $(".product_detail_show").hide();
      $(".shopping_cart_show").show();
      $("#category_name").text('Shopping Cart');
      
      

      var tr ='<tr class="shopping_row" id="shopping_td_'+k+'" data-id="'+k+'">'+
              '<td data-th="Product" >'+
                '<div class="row">'+
                  '<div class="col-sm-4 hidden-xs "><img src="'+src+'" alt="..." class="img-responsive product_image"/></div>'+
                  '<div class="col-sm-8">'+
                    '<h4 class="nomargin" id="product_name_'+k+'" >'+name+'</h4>'+
                    '<p class="product_description">'+description+' </p>'+
                  '</div>'+
                '</div>'+
              '</td>'+
              '<td data-th="Price" >$<span id="price_'+k+'">'+price+'</span></td>'+
              '<td data-th="Quantity">'+
                '<input type="number" class="form-control text-center product_quantity" value="1">'+
              '</td>'+
              '<td data-th="Subtotal" class="text-center">$<span id="subtotal_'+k+'" class="sub_total">'+price+'</span></td>'+
              '<td class="actions" data-th="">'+
                '<button class="btn btn-danger btn-sm data_remove"><i class="fa fa-trash-o"></i></button> '+               
              '</td>'+
            '</tr>';
            
      $(tr).appendTo( ".show_cart" ); 
      k++;
      calTotal();
      
  });

  $("#continue_shopping").on('click',function(){
    $(".product_detail_show").show();
      $(".shopping_cart_show").hide();
  });
  $("#make_payment").on('click',function(){
    
    location.href="payment_card.html";
      
  });
  

  $(document).on('click',"#Checkout",function(){
    if($("#total").text()=='0')
    {

      $('#noModal').modal('show');

    }
    else
    {
      $('#myModal').modal('show');
      var total_amount=$("#total").text();
      localStorage.setItem('amount',total_amount);
      
      
    }
    
  });

  //show products of all category
  if($("#container2").is(':visible')==true)
  {
      $.ajax({method: "GET",url: "product.json",dataType: "json"}).done(function(result)
    { var j=1;
      $.each(result,function(index,value){
        
        $.each(value,function(ind,val){
          // if(val.category=="new")
          // {

            $("#newproduct_"+j).find('.product_price').text(val.price);
            $("#newproduct_"+j).find('.product_name').text(val.productname);
            $("#newproduct_"+j).find('img').attr('src',val.src);
            $("#newproduct_"+j).find('.product_description').text(val.description);
            j++;
          //}

        });

      });

    });

  }
  //end
});

  // product page code
