$(document).ready(function(){
	var shopping_amount=localStorage.getItem('amount');
	localStorage.removeItem('amount');
	$(".amount").text(shopping_amount);
	 		
                 
});